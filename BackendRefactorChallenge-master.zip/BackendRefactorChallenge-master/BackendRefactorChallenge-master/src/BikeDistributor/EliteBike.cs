﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeDistributor
{
    class EliteBike : Bike
    {
        public EliteBike(string brand, string model) : base(brand, model)
        {
            this.Price = 2000;
        }

        public override int Price { get; set; }
    }
}
