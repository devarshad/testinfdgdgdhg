﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeDistributor
{
    public class DuraAceLine : Line
    {
        public DuraAceLine(Bike bike, int quantity) : base(bike, quantity)
        {
        }

        public override double DiscountPercentage => base.Quantity >= 10 ? 0.8d : 1d;
    }
}
