﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeDistributor
{
    public class DefyBike : Bike
    {
        public DefyBike(string brand, string model) : base(brand, model)
        {
            this.Price = 1000;
        }

        public override int Price { get; set; }
    }
}
