﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeDistributor
{
    class DuraAceBike : Bike
    {
        public DuraAceBike(string brand, string model) : base(brand, model)
        {
            this.Price = 5000;
        }

        public override int Price { get; set; }
    }
}
