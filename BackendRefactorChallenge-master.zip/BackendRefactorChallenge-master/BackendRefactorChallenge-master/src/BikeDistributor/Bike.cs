﻿namespace BikeDistributor
{
    public abstract class Bike
    {
        public Bike(string brand, string model)
        {
            Brand = brand;
            Model = model;
        }

        public string Brand { get; private set; }
        public string Model { get; private set; }
        public abstract int Price { get; set; }
    }
}
