﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeDistributor
{
    class Order_
    {
        private const double TaxRate = .0725d;
        private readonly IList<Line> _lines = new List<Line>();
        public Order_(string company)
        {
            Company = company;
        }
        public string Company { get; private set; }

        public void AddLine(Line line)
        {
            _lines.Add(line);
        }
    }
}
